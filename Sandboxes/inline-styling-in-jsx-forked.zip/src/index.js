import React from "react";
import ReactDOM from "react-dom";
// css use kabab case means they use dash ex: background-color
// jsx only suppots camel case so all html and css properties must need to
// convert into the camel case
// this is custom style object
// it is very easy to manipulate inline-style objects
const obj = {
  color: "red",
  // if youre going to write values with the unit so must include them in double quotes
  fontSize: "30px",
  backgroundColor: "yellow"
};

ReactDOM.render(
  // as string not supported in js so we have to use Object inside jsx for inline styling '
  // you have options though that put the Element directly inside the style or parse the Object
  // and just send data through a Object
  <div>
    <h1 style={{ color: "blue", fontSize: 50 }}>Hello World!</h1>
    <h2 style={obj}>Im ghansham, How are you?</h2>
  </div>,

  document.getElementById("root")
);
