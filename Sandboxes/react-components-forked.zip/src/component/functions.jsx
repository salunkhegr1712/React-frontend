import React from "react";

var obj = {
  Heading: function () {
    return <h1>My Favourite Foods</h1>;
  },
  List: function () {
    return (
      <ul>
        <li>Gulab Jamun</li>
        <li>Pedha</li>
        <li>Basundi</li>
        <li>Kachori</li>
      </ul>
    );
  }
};

export default obj;
