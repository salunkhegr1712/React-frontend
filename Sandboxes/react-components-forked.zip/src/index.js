// My Favourite Foods

//     Bacon
//     Jamon
//     Noodles

import React from "react";
// even if you dont know much but the  react is makes you use the html inside the JS
// so no matter what you have to add it your all js and jsx files

// it is also important that to add react in the functions/ Component file
import reactDome from "react-dom";
// importing the object from the another file where we declared the component
import obj from "./component/functions";
// import obj from "./functions"
// it is fine to not use .jsx extension as react is smart enough to recognise it
// lets make a Component now
// Component is also a function which return some html and it will start his name with capital letter
// just like the constructor  but component and the constructor is totally different

// single line component
function Heading() {
  return <h1>My Favourite Foods</h1>;
}

// multiple line component
function List() {
  // if you have multiple lines of html code so you can insert it with the help of common brackets
  return (
    <ul>
      <li>Gulab Jamun</li>
      <li>Pedha</li>
      <li>Basundi</li>
      <li>Kachori</li>
    </ul>
  );
}
reactDome.render(
  <div>
    {/* so we are going to use both the component declared inside the file itself and also
    the component which are imported from some another jsx file  */}
    <Heading></Heading>
    {/* we are using the object function as component so we must have to use the tag like structure  */}
    <obj.Heading />
    {/* <Heading/> as the heading dont have any child inside it so it can be acts like self
    closing tags and it is so much helpfull in shortning of your code */}
    <List />
    <obj.List />
    {/*list component which will return a unordred list which is found very helpfull */}
  </div>,
  document.getElementById("root")
);
