// firstly making sure that react us included in your database or not
const react = require("react");
const reactDom = require("react-dom");
// reactDom.render(
//   <h2>Hello World! Ghansham Here!!</h2>,
//   document.getElementById("ghansham")
// );

// reactDom.render(<h2>Hello World!</h2><h1>Ghansham Here!!</h1>,
//   document.getElementById("ghansham")); //Hello World! Ghansham Here!!
// SyntaxError
// /src/index.js: Adjacent JSX elements must be wrapped in an enclosing tag. Did you want a JSX fragment <>...</>? (5:37)

//   3 | const reactDom = require("react-dom");
//   4 |
// > 5 | reactDom.render(<h2>Hello World!</h2><h1>Ghansham Here!!</h1>,
//     |                                      ^
//   6 |   document.getElementById("ghansham"));
//   7 |

// if you want to store the code in Same tag to write down all the code and
// put that whole code inside a div or a section and it will word
// you can take any tag as parent to all the tags which you have in your code
// using p tag
reactDom.render(
  <p>
    <h2>Hello World!</h2>
    <h1>Ghansham here</h1>
  </p>,
  document.getElementById("ghansham")
); //Hello World! Ghansham Here!!
//Hello World!
// Ghansham here
// using section tag
reactDom.render(
  <section>
    <h2>Hello World!</h2>
    <h1>Ghansham here</h1>
  </section>,
  document.getElementById("ghansham")
);
