//Create a React app from scratch.
//Show a single h1 that says "Good morning" if between midnight and 12PM.
//or "Good Afternoon" if between 12PM and 6PM.
//or "Good evening" if between 6PM and midnight.
//Apply the "heading" style in the styles.css
//Dynamically change the color of the h1 using inline css styles.
//Morning = red, Afternoon = green, Night = blue.

import React from "react";
import reactDome from "react-dom";

// created a function which return a value and then i will fetch that value and
// that will be index for my main operation
function getMsg() {
  const day = new Date();
  let c = day.getHours();
  if (c >= 6 && c < 12) return 0;
  if (c >= 12 && c < 18) return 1;
  return 2;
}
// title and styling array which helps me to detect and and then just send the array
// block and answer is done
let arr = ["Good Morning", "Good Afternoon", "Good Night"];
let style = [{ color: "red" }, { color: "green" }, { color: "blue" }];

// console.log(arr);
// console.log(getMsg());
reactDome.render(
  <h1 className="heading" style={style[getMsg()]}>
    {arr[getMsg()]}
  </h1>,
  document.getElementById("root")
);
