// the r in react should be capital otherwise it will throw error
import React from "react";
import reactDome from "react-dom";

// just declaring the function and we will call all of the four functions with same
// external function where we can pass name of the function as the argument
function addition(a, b) {
  return a + b;
}

function substraction(a, b) {
  return a - b;
}
function multiplication(a, b) {
  return a * b;
}
function division(a, b) {
  return Math.floor(a / b);
}

// single function which will call all 4 other functions
function calculation(operation, a, b) {
  return operation(a, b);
}
// declaringtwo number where we Perform mathematical operation on them
// lets make this process work randomly
// Math.floor will make the number integer
let m = Math.floor(Math.random() * 100); // math.random will give you an decimal value from 0 to 1
let n = Math.floor(Math.random() * 20);
let fname = "Ghansham";
let lname = "Salunkhe";
// let luckyNumber = 17;
const a = [10, 20, 30, 40];
// just type {} whenever you need to use the js variable and it will rendered
// inside the html page also
reactDome.render(
  <div>
    {/* there are multiple ways to bring same output  */}
    {/* you can Perform string concatanation inside the js expressions  */}
    {/* <h1>Hello {fname + " " + lname}!</h1> */}
    {/* <h1>Hello {`${fname} ${lname}`}</h1> key above tab */}
    <h1>
      Hello {fname} {lname} !
    </h1>
    {/* you can insert one or many value with use of the curly braces  */}
    <p>
      My lucky number is {a[3]} {a[1]} {a[0]} {a[2]}
    </p>
    <p>
      numbers are m= {m} n= {n} <br></br>
      {/* we can call function or nested function also with the help of the JS expressions  */}
      Addition of them is : {calculation(addition, m, n)} <br></br>
      Substraction of them is : {calculation(substraction, m, n)} <br></br>
      Multiplication of them is : {calculation(multiplication, m, n)} <br></br>
      Division of them is : {calculation(division, m, n)} <br></br>
    </p>
    {/* My lucky number is 40 20 10 30 */}
  </div>,
  // just mark the changes at location inside the index.html file and
  // root is id of a div tag
  document.getElementById("root")
);
